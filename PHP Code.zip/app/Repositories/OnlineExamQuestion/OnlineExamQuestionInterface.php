<?php

namespace App\Repositories\OnlineExamQuestion;

use App\Repositories\Base\BaseInterface;

interface OnlineExamQuestionInterface extends BaseInterface {

}
