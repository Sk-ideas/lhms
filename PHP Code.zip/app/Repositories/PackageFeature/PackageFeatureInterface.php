<?php

namespace App\Repositories\PackageFeature;

use App\Repositories\Base\BaseInterface;

interface PackageFeatureInterface extends BaseInterface {

}
