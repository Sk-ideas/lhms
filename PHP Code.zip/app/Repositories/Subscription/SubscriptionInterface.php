<?php

namespace App\Repositories\Subscription;

use App\Repositories\Base\BaseInterface;

interface SubscriptionInterface extends BaseInterface {
    public function default();
}
