<?php

namespace App\Repositories\FeatureSection;

use App\Repositories\Base\BaseInterface;

interface FeatureSectionInterface extends BaseInterface {

}
