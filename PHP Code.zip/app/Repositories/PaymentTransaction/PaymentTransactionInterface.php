<?php

namespace App\Repositories\PaymentTransaction;

use App\Repositories\Base\BaseInterface;

interface PaymentTransactionInterface extends BaseInterface {

}
