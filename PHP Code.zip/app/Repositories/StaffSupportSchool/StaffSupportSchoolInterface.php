<?php

namespace App\Repositories\StaffSupportSchool;

use App\Repositories\Base\BaseInterface;

interface StaffSupportSchoolInterface extends BaseInterface {

}
