<?php

namespace App\Repositories\OptionalFee;

use App\Repositories\Base\BaseInterface;

interface OptionalFeeInterface extends BaseInterface {

}
