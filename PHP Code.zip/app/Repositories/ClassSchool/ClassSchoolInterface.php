<?php

namespace App\Repositories\ClassSchool;

use App\Repositories\Base\BaseInterface;

interface ClassSchoolInterface extends BaseInterface {

}
