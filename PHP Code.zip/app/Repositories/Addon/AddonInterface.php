<?php

namespace App\Repositories\Addon;

use App\Repositories\Base\BaseInterface;

interface AddonInterface extends BaseInterface {

}
