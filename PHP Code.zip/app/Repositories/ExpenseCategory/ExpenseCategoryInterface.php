<?php

namespace App\Repositories\ExpenseCategory;

use App\Repositories\Base\BaseInterface;

interface ExpenseCategoryInterface extends BaseInterface {

}
