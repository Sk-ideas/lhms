<?php

namespace App\Repositories\Languages;

use App\Repositories\Base\BaseInterface;

interface LanguageInterface extends BaseInterface {

}
