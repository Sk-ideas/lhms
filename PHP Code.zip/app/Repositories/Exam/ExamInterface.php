<?php

namespace App\Repositories\Exam;

use App\Repositories\Base\BaseInterface;

interface ExamInterface extends BaseInterface {

}
