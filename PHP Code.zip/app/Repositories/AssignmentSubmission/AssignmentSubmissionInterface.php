<?php

namespace App\Repositories\AssignmentSubmission;

use App\Repositories\Base\BaseInterface;

interface AssignmentSubmissionInterface extends BaseInterface {

}
