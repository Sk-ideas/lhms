<?php

namespace App\Repositories\FeesClassType;

use App\Repositories\Base\BaseInterface;

interface FeesClassTypeInterface extends BaseInterface {

}
