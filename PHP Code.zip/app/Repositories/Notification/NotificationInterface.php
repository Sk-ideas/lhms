<?php

namespace App\Repositories\Notification;

use App\Repositories\Base\BaseInterface;

interface NotificationInterface extends BaseInterface {

}
