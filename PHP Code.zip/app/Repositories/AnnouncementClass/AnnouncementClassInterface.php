<?php

namespace App\Repositories\AnnouncementClass;

use App\Repositories\Base\BaseInterface;

interface AnnouncementClassInterface extends BaseInterface {

}
