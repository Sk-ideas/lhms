<?php

namespace App\Repositories\Stream;

use App\Repositories\Base\BaseInterface;

interface StreamInterface extends BaseInterface {

}
