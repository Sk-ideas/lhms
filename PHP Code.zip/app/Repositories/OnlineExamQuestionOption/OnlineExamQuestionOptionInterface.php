<?php

namespace App\Repositories\OnlineExamQuestionOption;

use App\Repositories\Base\BaseInterface;

interface OnlineExamQuestionOptionInterface extends BaseInterface {

}
