<?php

namespace App\Repositories\Expense;

use App\Repositories\Base\BaseInterface;

interface ExpenseInterface extends BaseInterface {

}
