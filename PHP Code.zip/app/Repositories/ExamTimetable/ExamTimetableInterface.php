<?php

namespace App\Repositories\ExamTimetable;

use App\Repositories\Base\BaseInterface;

interface ExamTimetableInterface extends BaseInterface {

}
