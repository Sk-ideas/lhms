<?php

namespace App\Repositories\FeesInstallment;

use App\Repositories\Base\BaseInterface;

interface FeesInstallmentInterface extends BaseInterface {
    public function default();

}
