<?php

namespace App\Repositories\SubscriptionFeature;

use App\Repositories\Base\BaseInterface;

interface SubscriptionFeatureInterface extends BaseInterface {

}
