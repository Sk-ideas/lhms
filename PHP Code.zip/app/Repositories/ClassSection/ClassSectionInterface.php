<?php

namespace App\Repositories\ClassSection;

use App\Repositories\Base\BaseInterface;

interface ClassSectionInterface extends BaseInterface {

}

