<?php

namespace App\Repositories\Sliders;

use App\Repositories\Base\BaseInterface;

interface SlidersInterface extends BaseInterface {

}
