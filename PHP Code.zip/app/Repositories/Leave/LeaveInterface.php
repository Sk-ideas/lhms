<?php

namespace App\Repositories\Leave;

use App\Repositories\Base\BaseInterface;

interface LeaveInterface extends BaseInterface {

}
