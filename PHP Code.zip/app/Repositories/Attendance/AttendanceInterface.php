<?php

namespace App\Repositories\Attendance;

use App\Repositories\Base\BaseInterface;

interface AttendanceInterface extends BaseInterface {

}
