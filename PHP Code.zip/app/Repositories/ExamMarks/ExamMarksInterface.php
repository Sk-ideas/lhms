<?php

namespace App\Repositories\ExamMarks;

use App\Repositories\Base\BaseInterface;

interface ExamMarksInterface extends BaseInterface {

}
