<?php

namespace App\Repositories\OnlineExam;

use App\Repositories\Base\BaseInterface;

interface OnlineExamInterface extends BaseInterface {

}
