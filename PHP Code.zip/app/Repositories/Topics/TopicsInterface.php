<?php

namespace App\Repositories\Topics;

use App\Repositories\Base\BaseInterface;

interface TopicsInterface extends BaseInterface {

}
