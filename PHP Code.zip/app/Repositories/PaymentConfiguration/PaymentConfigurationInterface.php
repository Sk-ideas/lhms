<?php

namespace App\Repositories\PaymentConfiguration;

use App\Repositories\Base\BaseInterface;

interface PaymentConfigurationInterface extends BaseInterface {

}
